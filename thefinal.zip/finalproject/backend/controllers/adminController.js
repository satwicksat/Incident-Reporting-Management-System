const User = require("../models/User");
const Incident = require("../models/Incident");
const Alert = require("../models/Alert");
const ActivityLog = require("../models/ActivityLog");

exports.getStats = async (req, res) => {
  const users = await User.countDocuments();
  const incidents = await Incident.countDocuments();
  const alerts = await Alert.countDocuments();
  const logs = await ActivityLog.countDocuments();

  res.json({ users, incidents, alerts, logs });
};

exports.getUsers = async (req, res) => {
  res.json(await User.find().select("-password"));
};

exports.getIncidents = async (req, res) => {
  res.json(await Incident.find().populate("userId", "name email"));
};

exports.getAlerts = async (req, res) => {
  res.json(await Alert.find().populate("userId", "name email").populate("incidentId"));
};

exports.getActivityLogs = async (req, res) => {
  res.json(await ActivityLog.find().populate("userId", "name email").sort({ createdAt: -1 }));
};

exports.deleteUser = async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.json({ msg: "User deleted" });
};

exports.deleteIncident = async (req, res) => {
  await Incident.findByIdAndDelete(req.params.id);
  res.json({ msg: "Incident deleted" });
};