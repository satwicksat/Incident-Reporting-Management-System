const Incident = require("../models/Incident");
const User = require("../models/User");
const Alert = require("../models/Alert");
const ActivityLog = require("../models/ActivityLog");

exports.create = async (req, res) => {
  try {
    const incident = await Incident.create({
      ...req.body,
      userId: req.user.id
    });

    // Send notifications to all users (except reporter)
    const users = await User.find({ _id: { $ne: req.user.id } });
    const alerts = users.map(user => ({
      message: `New incident reported: ${incident.title} at ${incident.address || `${incident.lat}, ${incident.lng}`}`,
      userId: user._id,
      incidentId: incident._id
    }));
    await Alert.insertMany(alerts);

    // Log incident creation
    await ActivityLog.create({
      action: "report_incident",
      userId: req.user.id,
      details: { title: incident.title, address: incident.address, lat: incident.lat, lng: incident.lng },
      ip: req.ip,
      userAgent: req.get("User-Agent")
    });

    res.json(incident);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Error creating incident" });
  }
};

exports.getAll = async (req, res) => {
  const data = await Incident.find().sort({ createdAt: -1 });
  res.json(data);
};

exports.delete = async (req, res) => {
  await Incident.findByIdAndDelete(req.params.id);
  res.json({ msg: "Deleted" });
};