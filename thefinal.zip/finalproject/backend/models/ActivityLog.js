const mongoose = require("mongoose");

module.exports = mongoose.model("ActivityLog", {
  action: String, // e.g., "login", "register", "report_incident"
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  details: mongoose.Schema.Types.Mixed, // additional data
  ip: String,
  userAgent: String,
  createdAt: { type: Date, default: Date.now }
});