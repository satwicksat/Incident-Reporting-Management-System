const mongoose = require("mongoose");

module.exports = mongoose.model("Incident", {
  title: String,
  description: String,
  address: String,
  lat: Number,
  lng: Number,
  userId: mongoose.Schema.Types.ObjectId,
  createdAt: { type: Date, default: Date.now }
});