const mongoose = require("mongoose");

module.exports = mongoose.model("Alert", {
  message: String,
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  incidentId: { type: mongoose.Schema.Types.ObjectId, ref: "Incident" },
  createdAt: { type: Date, default: Date.now }
});