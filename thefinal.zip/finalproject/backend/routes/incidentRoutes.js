const router = require("express").Router();
const ctrl = require("../controllers/incidentController");
const auth = require("../middleware/auth");

router.post("/", auth, ctrl.create);
router.get("/", ctrl.getAll);
router.delete("/:id", auth, ctrl.delete);

module.exports = router;