const router = require("express").Router();
const Alert = require("../models/Alert");
const auth = require("../middleware/auth");

router.get("/", auth, async (req, res) => {
  const alerts = await Alert.find({ userId: req.user.id }).populate("incidentId").sort({ createdAt: -1 });
  res.json(alerts);
});

module.exports = router;