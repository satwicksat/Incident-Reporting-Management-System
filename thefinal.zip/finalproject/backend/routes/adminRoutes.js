const router = require("express").Router();
const ctrl = require("../controllers/adminController");
const auth = require("../middleware/auth");
const admin = require("../middleware/admin");

router.get("/stats", auth, admin, ctrl.getStats);
router.get("/users", auth, admin, ctrl.getUsers);
router.get("/incidents", auth, admin, ctrl.getIncidents);
router.get("/alerts", auth, admin, ctrl.getAlerts);
router.get("/logs", auth, admin, ctrl.getActivityLogs);
router.delete("/user/:id", auth, admin, ctrl.deleteUser);
router.delete("/incident/:id", auth, admin, ctrl.deleteIncident);

module.exports = router;