const path = require("path");
const express = require("express");
const cors = require("cors");
require("dotenv").config({ path: path.join(__dirname, ".env") });

const connectDB = require("./config/db");
const User = require("./models/User");
const bcrypt = require("bcryptjs");

const app = express();

app.use(cors());
app.use(express.json());

// TEST ROUTE
app.get("/", (req, res) => {
  res.send("Backend is running");
});

// ROUTES
const authRoutes = require("./routes/authRoutes");
const incidentRoutes = require("./routes/incidentRoutes");
const alertRoutes = require("./routes/alertRoutes");
const adminRoutes = require("./routes/adminRoutes");

app.use("/api/auth", authRoutes);
app.use("/api/incidents", incidentRoutes);
app.use("/api/alerts", alertRoutes);
app.use("/api/admin", adminRoutes);

async function ensureAdminUser() {
  const adminEmail = "admin@gmail.com";
  const adminPassword = "admin123";
  const hash = await bcrypt.hash(adminPassword, 10);

  await User.updateOne(
    { email: adminEmail },
    { $set: { name: "Admin", password: hash, role: "admin" } },
    { upsert: true }
  );

  console.log("Ensured admin user:", adminEmail);
}

// Connect to DB and start server
connectDB().then(async () => {
  await ensureAdminUser();
  app.listen(process.env.PORT || 5000, () => {
    console.log(`Server running on port ${process.env.PORT || 5000}`);
  });
});