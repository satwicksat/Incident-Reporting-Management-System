const path = require("path");
require("dotenv").config({ path: path.join(__dirname, ".env") });
const mongoose = require("mongoose");
const User = require("./models/User");
const bcrypt = require("bcryptjs");

async function seed() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("Connected to DB");

    const adminEmail = "admin@gmail.com";
    const adminPassword = "admin123";
    const hash = await bcrypt.hash(adminPassword, 10);

    await User.updateOne(
      { email: adminEmail },
      { $set: { name: "Admin", password: hash, role: "admin" } },
      { upsert: true }
    );

    console.log("Admin user ensured:", adminEmail);
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

seed();