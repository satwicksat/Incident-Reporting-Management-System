import { request } from "../core/api.js";
import { requireAuth, createAdminLink, logout } from "../core/auth.js";
import { init } from "../core/init.js";

init(() => {
  requireAuth();
  createAdminLink();

  const form = document.getElementById("form");
  const locationType = document.getElementsByName("locationType");
  const manualLocation = document.getElementById("manualLocation");
  const title = document.getElementById("title");
  const desc = document.getElementById("desc");
  const addressInput = document.getElementById("address");

  // Handle location type change
  locationType.forEach(radio => {
    radio.addEventListener("change", () => {
      if (radio.value === "manual") {
        manualLocation.style.display = "block";
      } else {
        manualLocation.style.display = "none";
      }
    });
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    let lat = null, lng = null, address = "";

    if (document.querySelector('input[name="locationType"]:checked').value === "current") {
      // Get current location
      if (!navigator.geolocation) {
        alert("Geolocation not supported");
        return;
      }
      navigator.geolocation.getCurrentPosition(async (pos) => {
        lat = pos.coords.latitude;
        lng = pos.coords.longitude;
        await submitIncident(lat, lng, address);
      }, () => {
        alert("Unable to get location. Please allow location access.");
      });
    } else {
      // Manual address
      address = addressInput.value;
      await submitIncident(lat, lng, address);
    }
  });

  async function submitIncident(lat, lng, address) {
    try {
      await request("/incidents", "POST", {
        title: title.value,
        description: desc.value,
        address,
        lat,
        lng
      });

      alert("Incident reported successfully!");
      window.location.href = "dashboard.html";
    } catch (err) {
      alert("Error reporting incident: " + err.message);
    }
  }
});