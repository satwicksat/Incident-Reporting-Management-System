import { request } from "../core/api.js";
import { requireAuth, createAdminLink, logout } from "../core/auth.js";
import { init } from "../core/init.js";

init(async () => {
  requireAuth();
  createAdminLink();

  const data = await request("/incidents");

  document.getElementById("data").innerHTML =
    data.map(i => `
      <div class="card">
        <h3>${i.title}</h3>
        <p>${i.description}</p>
        <p>${i.address || 'Location not specified'}</p>
      </div>
    `).join("");

  // Logout
  document.getElementById("logout").addEventListener("click", () => {
    logout();
  });
});