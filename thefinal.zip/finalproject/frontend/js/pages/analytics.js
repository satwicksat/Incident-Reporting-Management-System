import { request } from "../core/api.js";
import { init } from "../core/init.js";

init(async () => {
  const data = await request("/incidents");

  const counts = {};

  data.forEach(i => {
    const date = new Date(i.createdAt).toLocaleDateString();
    counts[date] = (counts[date] || 0) + 1;
  });

  new Chart(document.getElementById("chart"), {
    type: "line",
    data: {
      labels: Object.keys(counts),
      datasets: [{
        label: "Incidents",
        data: Object.values(counts)
      }]
    }
  });
});