import { request } from "../core/api.js";
import { requireAdmin, logout } from "../core/auth.js";
import { init } from "../core/init.js";

init(async () => {
  requireAdmin();

  // Stats
  const stats = await request("/admin/stats");
  document.getElementById("stats").innerHTML = `
    <h3>Statistics</h3>
    <p>Users: ${stats.users} | Incidents: ${stats.incidents} | Alerts: ${stats.alerts} | Logs: ${stats.logs}</p>
  `;

  // Users
  const users = await request("/admin/users");
  document.getElementById("users").innerHTML = users.map(u => `
    <div>${u.name} (${u.email}) - ${u.role}
      <button onclick="deleteUser('${u._id}')">Delete</button>
    </div>
  `).join("");

  // Incidents
  const incidents = await request("/admin/incidents");
  document.getElementById("incidents").innerHTML = incidents.map(i => `
    <div>${i.title} by ${i.userId?.name || 'Unknown'} at ${i.address || `${i.lat}, ${i.lng}`}
      <button onclick="deleteIncident('${i._id}')">Delete</button>
    </div>
  `).join("");

  // Alerts
  const alerts = await request("/admin/alerts");
  document.getElementById("alerts").innerHTML = alerts.map(a => `
    <div>${a.message} to ${a.userId?.name || 'Unknown'}</div>
  `).join("");

  // Logs
  const logs = await request("/admin/logs");
  document.getElementById("logs").innerHTML = logs.slice(0, 10).map(l => `
    <div>${l.action} by ${l.userId?.name || 'Unknown'} at ${new Date(l.createdAt).toLocaleString()}</div>
  `).join("");

  // Logout
  document.getElementById("logout").addEventListener("click", () => {
    logout();
  });
});

// Global functions for onclick
window.deleteUser = async (id) => {
  await request(`/admin/user/${id}`, "DELETE");
  location.reload();
};

window.deleteIncident = async (id) => {
  await request(`/admin/incident/${id}`, "DELETE");
  location.reload();
};