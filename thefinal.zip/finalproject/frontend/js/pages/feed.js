import { request } from "../core/api.js";
import { requireAuth, createAdminLink, logout } from "../core/auth.js";
import { init } from "../core/init.js";

init(async () => {
  requireAuth();
  createAdminLink();

  const incidents = await request("/incidents");
  const container = document.getElementById("incidents");

  container.innerHTML = incidents.map(i => `
    <div class="card">
      <h3>${i.title}</h3>
      <p>${i.description}</p>
      <p>${i.address || 'Location not specified'}</p>
      <small>Reported at ${new Date(i.createdAt).toLocaleString()}</small>
    </div>
  `).join("");

  // Logout
  document.getElementById("logout").addEventListener("click", () => {
    logout();
  });
});