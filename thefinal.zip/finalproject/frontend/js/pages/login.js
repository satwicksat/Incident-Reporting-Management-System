import { request } from "../core/api.js";

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("form");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    // get values
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    try {
      const res = await request("/auth/login", "POST", {
        email,
        password
      });

      console.log("LOGIN RESPONSE:", res);

      // success
      if (res.token) {
        localStorage.setItem("token", res.token);
        localStorage.setItem("role", res.role || "user");

        alert("Login successful");

        if (res.role === "admin") {
          window.location.href = "admin.html";
        } else {
          window.location.href = "dashboard.html";
        }
      } else {
        alert(res.msg || "Login failed");
      }

    } catch (err) {
      console.error("LOGIN ERROR:", err);
      alert(err.message || "Server error");
    }
  });
});