import { request } from "../core/api.js";
import { init } from "../core/init.js";
import { createAdminLink } from "../core/auth.js";

init(async () => {
  createAdminLink();
  const map = L.map('map').setView([20,77],5);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png')
    .addTo(map);

  const data = await request("/incidents");

  data.forEach(i => {
    if (i.lat && i.lng) {
      const popupContent = `${i.title}<br>${i.description}<br>${i.address || ''}`;
      L.marker([i.lat, i.lng]).addTo(map).bindPopup(popupContent);
    }
  });
});