import { request } from "../core/api.js";

console.log("REGISTER JS LOADED");

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("form");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    console.log("Submitting...");

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const res = await request("/auth/register", "POST", {
      name,
      email,
      password
    });

    console.log(res);

    alert("Registered!");
    window.location.href = "login.html";
  });
});