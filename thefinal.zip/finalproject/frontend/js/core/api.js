export const API = "http://localhost:5000/api";

export async function request(url, method = "GET", body = null) {
  const token = localStorage.getItem("token");

  const res = await fetch(API + url, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token && { Authorization: "Bearer " + token })
    },
    body: body ? JSON.stringify(body) : null
  });

  const data = await res.json();

  if (!res.ok) {
    console.error("API ERROR:", data);
    throw new Error(data.msg || "Server error");
  }

  return data;
}