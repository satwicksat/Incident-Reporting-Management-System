export function init(cb) {
  document.addEventListener("DOMContentLoaded", cb);
}