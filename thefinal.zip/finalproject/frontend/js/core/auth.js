export function getToken() {
  return localStorage.getItem("token");
}

export function getRole() {
  return localStorage.getItem("role");
}

export function isAdmin() {
  return getRole() === "admin";
}

export function requireAuth() {
  if (!getToken()) {
    window.location.href = "login.html";
  }
}

export function requireAdmin() {
  requireAuth();
  if (!isAdmin()) {
    window.location.href = "dashboard.html";
  }
}

export function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("role");
  window.location.href = "login.html";
}

export function createAdminLink() {
  if (!getToken() || !isAdmin()) return;
  const nav = document.querySelector(".nav div");
  if (!nav) return;
  if (document.getElementById("nav-admin-link")) return;

  const link = document.createElement("a");
  link.id = "nav-admin-link";
  link.href = "admin.html";
  link.textContent = "Admin";

  const logout = document.getElementById("logout");
  if (logout) {
    nav.insertBefore(link, logout);
  } else {
    nav.appendChild(link);
  }
}